<?php
?>

<input class="menu-icon" type="checkbox" id="menu-icon" name="menu-icon"/>
<label for="menu-icon"></label>

<nav class="nav">
    <ul class="pt-5">
        <li><a href="/socset/">Главная</a></li>
        <?php
            if (isset($_SESSION['id'])){
            echo '<li><a href="http://localhost/socset/profile/accaunt.php">Личный
            кабинет</a></li>';
            }else {
            echo '<li><a href="http://localhost/socset/auth.php">Личный
            кабинет</a></li>';
            }
            if (isset($_SESSION['id'])){
            echo '<li><a
            href="http://localhost/socset/chat/chat.php">Чат</a></li>';
            }else {
            echo '<li><a href="http://localhost/socset/auth.php">Чат</a></li>';
            }
            ?>
            <li><a href="http://localhost/socset/posts/posts.php">Новости</a></li>
            <li><a href = "http://localhost/socset/game/games.php">Игра</a></li>
            <?php
            if (isset($_SESSION['id'])) {
            echo '<li><a
            href="http://localhost/socset/shop/shop.php">Магазин</a></li>';
            } else {
            echo '<li><a
            href="http://localhost/socset/auth.php">Магазин</a></li>';
            }
            ?>
        <?php if (isset($_SESSION['id'])): ?>
            <!-- Авторизованный пользователь -->
             <li><a href="http://localhost/socset/video/all_videos.php">Видео</a></li>
            <li><a href="/socset/profile/accaunt.php">Личный кабинет</a></li>
            <li><a href="/socset/chat/chat.php">Чат</a></li>

            <li>
                <a href="/socset/posts/createpost.php" class="create-post-btn">
                    Создать пост
                </a>
            </li>

        <?php else: ?>
            <li><a href="/socset/auth.php">Личный кабинет</a></li>
        <?php endif; ?>

        
    </ul>
</nav>